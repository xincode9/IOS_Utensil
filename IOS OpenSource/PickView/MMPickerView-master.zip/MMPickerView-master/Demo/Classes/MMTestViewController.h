//
//  MMTestViewController.h
//  MMPickerView
//
//  Created by Madjid Mahdjoubi on 6/7/13.
//  Copyright (c) 2013 GG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMPickerView.h"

@interface MMTestViewController : UIViewController
- (IBAction)showPickerViewButtonPressed:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *label;

@end
